The password for test1234.tzp is "test1234" - enjoy the fun!
