This directory tree is a test parcours for the TrueZIP API. It contains a
mix of ZIP compatible files as well as false positive ZIP compatible files,
i.e. files or directories which appear to be ZIP compatible files according
to their path name, but actually aren't.

Note that any of these files or directories aren't used in the JUnit tests.
This is first of all because unit tests may be executed outside of the project
directory and second of all because they create false positives on their own.
Still some of these files should be incorporated in the tests as a future
enhancement in order to test ZIP file formats or contents which are not
creatable by TrueZIP, such as ghost directories or STORED entries in a ZIP file
(although they are treated correctly and preserved if found in an externally
created ZIP file).